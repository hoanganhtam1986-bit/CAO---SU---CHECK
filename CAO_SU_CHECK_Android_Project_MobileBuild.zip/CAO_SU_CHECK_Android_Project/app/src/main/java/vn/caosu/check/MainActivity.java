package vn.caosu.check;
import android.app.*; import android.content.*; import android.net.Uri; import android.os.*; import android.util.Base64; import android.webkit.*; import android.widget.Toast; import java.io.OutputStream;
public class MainActivity extends Activity {
 WebView web; ValueCallback<Uri[]> fileCallback; String exportData="", exportName="", exportMime="application/octet-stream";
 static final int SAVE=4101, OPEN=4102;
 public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);web.addJavascriptInterface(new Bridge(),"Android");
 web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){fileCallback=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,OPEN);return true;}});
 web.loadUrl("file:///android_asset/index.html");}
 class Bridge {@JavascriptInterface public void saveFile(String name,String data,String mime){runOnUiThread(()->{exportName=name;exportData=data;exportMime=mime;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,SAVE);});}}
 protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==SAVE&&res==RESULT_OK&&data!=null){try(OutputStream o=getContentResolver().openOutputStream(data.getData())){o.write(Base64.decode(exportData,Base64.DEFAULT));Toast.makeText(this,"Đã lưu tệp",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Lỗi lưu tệp",Toast.LENGTH_SHORT).show();}}else if(req==OPEN&&fileCallback!=null){fileCallback.onReceiveValue(res==RESULT_OK&&data!=null?new Uri[]{data.getData()}:null);fileCallback=null;}}
 public void onBackPressed(){new AlertDialog.Builder(this).setMessage("Thoát CAO SU CHECK?").setNegativeButton("Ở lại",null).setPositiveButton("Thoát",(d,w)->finish()).show();}
}
