CAO SU CHECK – DỰ ÁN ANDROID 1.3

Chức năng:
- Chạy offline trong ứng dụng Android; giao diện HTML được đóng gói trong APK.
- Lưu dữ liệu trên thiết bị bằng localStorage.
- Kiểm kê từng cây theo hàng với mã ✓, K1, K2, O, M, G.
- Tự tính cây đứng = tổng cây - O - M - G.
- Lưu phiếu kiểm kê gồm từng hàng và trạng thái từng cây.
- Có danh sách phiếu đã lưu; xem chi tiết, sửa, xóa phiếu.
- Xuất CSV, sao lưu và khôi phục JSON bằng bộ chọn tệp Android.

Tạo APK:
1. Mở thư mục này bằng Android Studio.
2. Chờ Gradle Sync (lần đầu cần Internet để tải Android Gradle Plugin/SDK).
3. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK nằm ở app/build/outputs/apk/debug/app-debug.apk.

Lưu ý: Đây là mã nguồn Android Studio, chưa phải APK đã biên dịch. Môi trường hiện tại không có Android SDK/Gradle để tạo và kiểm thử APK. Sao lưu JSON trước khi gỡ ứng dụng vì dữ liệu được lưu cục bộ.
